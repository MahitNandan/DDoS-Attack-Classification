from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np
import joblib

app = Flask(__name__)
model = joblib.load('RF_model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on GUI
    '''
    features = [x for x in request.form.values()]
    final_features = [features]
    example_features = [[7354.121,7242.0,-1,942.7286,30.703886,0.0,0.0,0,-1,-1,0.0,30.127623,0.0,106,0]]
    prediction = model.predict(final_features)
    prediction_class = {0:"Benign", 1:"DNS", 2:"LDAP", 3:"MSSQL", 4:"NTP", 5:"NetBIOS", 6:"Portmap", 7:"SNMP", 8:"Syn", 9:"TFTP", 10:"UDP", 11:"UDPLag", 12:"WebDDoS"}

    output = prediction_class[prediction[0]]
    import csv
    input_file = "predictions.csv"
    new_row = features
    new_row.append(output)
    with open(input_file, 'r', newline='') as infile:
        reader = csv.reader(infile)
        data = list(reader)
    with open(input_file, 'a', newline='') as outfile:
        writer = csv.writer(outfile)
        writer.writerow(new_row)
    return render_template('index.html', prediction_text='Type of DDoS Attack : {}'.format(output))

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)